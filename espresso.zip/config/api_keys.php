<?php

return [
    'PAYMONGO_PUBLIC_KEY' => 'pk_test_5vG1sfcLtwuqcZbL9qAJHHFq',
    'PAYMONGO_SECRET_KEY' => 'sk_test_xEpXHanDYhXfVwY5XyXNUtBY',

    'GOOGLE_CLIENT_ID' => '953398952669-r0tlimpoprv18pfgis5u39dk4r0t83p5.apps.googleusercontent.com',
    'GOOGLE_CLIENT_SECRET' => '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',
    'GOOGLE_REDIRECT_URI' => 'http://localhost:8000/login/google/callback',
];
