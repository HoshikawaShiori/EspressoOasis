
<?php $__env->startSection('title'); ?>
    APIS
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.admintopNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container p-5">
    <form class="bg-light p-3 border rounded" method="post" action="<?php echo e(route('updateMongoKeys')); ?>">
        <?php echo csrf_field(); ?>
        <fieldset>
            <legend>PAYMONGO API KEYS</legend>
            <div class="row mb-3">
                <label for="paymongoPublicKey" class="col-sm-2 col-form-label">Public key</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="paymongoPublicKey" name="paymongoPublicKey" value="<?php echo e(config('api_keys.PAYMONGO_PUBLIC_KEY')); ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label for="paymongoSecretKey" class="col-sm-2 col-form-label">Secret key</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="paymongoSecretKey" name="paymongoSecretKey" value="<?php echo e(config('api_keys.PAYMONGO_SECRET_KEY')); ?>">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-sm-10 offset-sm-2">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </fieldset>
    </form>
    
    <form class="bg-light p-3 border rounded mt-3">
        <fieldset>
            <legend>Google Keys</legend>
            <div class="row mb-3">
                <label for="googleClientID" class="col-sm-2 col-form-label">Google Client ID</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="googleClientID" name="googleClientID" value="<?php echo e(config('api_keys.GOOGLE_CLIENT_ID')); ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label for="googleClientSecret" class="col-sm-2 col-form-label">Google Client Secret</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="googleClientSecret" name="googleClientSecret" value="<?php echo e(config('api_keys.GOOGLE_CLIENT_SECRET')); ?>">
                </div>
            </div>
            <div class="row mb-3">
                <label for="googleRedirectURI" class="col-sm-2 col-form-label">Google Redirect URI</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="googleRedirectURI" name="googleRedirectURI" value="<?php echo e(config('api_keys.GOOGLE_REDIRECT_URI')); ?>">
                </div>
            </div>
            <div class="row mb-3">
                <div class="col-sm-10 offset-sm-2">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </fieldset>
    </form>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jom\espressoOasis\resources\views/admin/apis.blade.php ENDPATH**/ ?>