
<?php $__env->startSection('title'); ?>
    Shop
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::to('src/css/shop-card.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if(count($errors) > 0): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>



        <h1 class=" display-4 text-center pt-5 pe-0 shop-head">Brewery</h1>
        <div class="row row-cols-1 row-cols-md-2 g-4">

            <?php $__currentLoopData = $coffees->chunk(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coffeeChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $coffeeChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coffee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <div class="card border-0">
                            <div class="card-header border-0">
                                <!-- Image -->
                                <img src="<?php echo e($coffee->imagePath); ?>" alt="Profile Image" class="profile-img">
                            </div>
                            <div class="card-body border-0 pt-5 px-0">
                                <!-- Coffee title -->
                                <h4 class="name"><?php echo e($coffee->title); ?></h4>
                                <!-- Brew -->
                                <p class="fs-6 pt-0 pb-0 text-secondary">Brew</p>
                                <div class="row align-items-center pt-0">
                                    <!-- Form for adding to cart -->
                                    <form id="addToCartForm<?php echo e($coffee->id); ?>"
                                        action='<?php echo e(route('coffee.addToCart', ['id' => $coffee->id, 'sizeIndex' => $coffee->sizes[0]['label'], 'brew' => 'option'])); ?>'>
                                        <div class="col pe-0 pb-3">
                                            <!-- Radio buttons for selecting options -->
                                            <input type="radio" class="btn-check btn-sm"
                                                name="<?php echo e($coffee->title); ?>-options" id="<?php echo e($coffee->title); ?>-Hot"
                                                autocomplete="off" value="Hot" required>
                                            <label class="btn" for="<?php echo e($coffee->title); ?>-Hot">Hot</label>
                                            <input type="radio" class="btn-check btn-sm"
                                                name="<?php echo e($coffee->title); ?>-options" id="<?php echo e($coffee->title); ?>-Iced"
                                                autocomplete="off" value="Iced" required>
                                            <label class="btn" for="<?php echo e($coffee->title); ?>-Iced">Iced</label>
                                        </div>
                                        <div class="row align-items-center pt-0 mx-4">
                                            <!-- Range input for selecting sizes -->
                                            <label for="customRange1" class="form-label pb-0">Sizes</label>
                                            <input type="range" class="form-range" id="customRange<?php echo e($coffee->id); ?>"
                                                min="0" max="<?php echo e(count($coffee->sizes) - 1); ?>" step="1"
                                                list="sizes<?php echo e($coffee->id); ?>" value="0">
                                            <datalist id="sizes<?php echo e($coffee->id); ?>">
                                                <!-- Options for the range input -->
                                                <?php $__currentLoopData = $coffee->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($index); ?>" label="<?php echo e($size['label']); ?>"
                                                        class="text-secondary"></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </datalist>
                                        </div>
                                        <!-- Button for submitting form -->
                                        <div class="card-footer border-0">
                                            <div class="row align-items-center pt-0">
                                                <div class="col ps-0">
                                                    <!-- Price display -->
                                                    <h2><span>&#8369;</span><span
                                                            id="price<?php echo e($coffee->id); ?>"><?php echo e($coffee->sizes[0]['price']); ?></span>
                                                    </h2>
                                                </div>
                                                <div class="col ps-3 pe-2 ms-0">
                                                    <button type="submit" class="btn btn-circle btn-xl border-0"><i
                                                            class="fa-solid fa-plus" style="color: #ffffff;"></i></button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
    </div>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

<?php $__env->startSection('scripts'); ?>
    <?php $__currentLoopData = $coffees->chunk(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coffeeChunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $coffeeChunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coffee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <script>
                $(document).ready(function() {
                    $('input[name="<?php echo e($coffee->title); ?>-options"]').change(function() {
                        let selectedValue = $('input[name="<?php echo e($coffee->title); ?>-options"]:checked').val();

                        if (selectedValue) {
                            console.log(
                                selectedValue); // Log the value of the selected radio button ("Hot" or "Iced")
                        } else {
                            console.log('No option selected'); // If no option is selected
                        }
                    });
                });
            </script>

            <script>
                $(document).ready(function() {
                    var sizes = JSON.parse('<?php echo addslashes(json_encode($coffee->sizes)); ?>'); // Parse sizes array from PHP to JavaScript

                    $('#customRange<?php echo e($coffee->id); ?>').on('input', function() {
                        var selectedSize = $(this).val();
                        var price = sizes[0]['price']; // Default price for the first size

                        if (selectedSize >= 0 && selectedSize < sizes.length) {
                            price = sizes[selectedSize]['price']; // Get price based on selected size index
                        }
                        console.log($('#customRange<?php echo e($coffee->id); ?>').val());

                        $('#price<?php echo e($coffee->id); ?>').text(price);
                    });
                });
            </script>


            <script>
                $(document).ready(function() {
                    $('#addToCartForm<?php echo e($coffee->id); ?>').on('submit', function(event) {
                        event.preventDefault();

                        var sizeRange = document.getElementById('customRange<?php echo e($coffee->id); ?>');
                        var selectedSize = sizeRange.value;

                        var selectedOptionValue = $('input[name="<?php echo e($coffee->title); ?>-options"]:checked').val();

                        if (selectedSize >= 0 && selectedSize < <?php echo e(count($coffee->sizes)); ?>) {
                            var newAction =
                                '<?php echo e(route('coffee.addToCart', ['id' => $coffee->id, 'sizeIndex' => ':sizeIndex', 'brew' => ':brew'])); ?>';
                            newAction = newAction.replace(':sizeIndex', selectedSize);
                            newAction = newAction.replace(':brew', selectedOptionValue);

                            $(this).attr('action', newAction);
                        }

                        this.submit();
                    });
                });

            </script>

            <script>
                $(document).ready(function () {
                    // Remove 'fixed-top' class onload
                    $('#navbar').removeClass('fixed-top');

                    $(window).scroll(function () {
                        // Add 'fixed-top' class on scroll
                        if ($(this).scrollTop() > 50) {
                            $('#navbar').addClass('fixed-top');
                        } else {
                            $('#navbar').removeClass('fixed-top');
                        }
                    });
                });
            </script>


            <script>
                $(document).ready(function() {

                    $(window).scroll(function() {
                        var navbar = $("#navbar");
                        if ($(window).scrollTop() > 50) {
                            navbar.removeClass("navbar-transparent").addClass("bg-light");
                        } else {
                            navbar.removeClass("bg-light").addClass("navbar-transparent");
                        }
                    });
                });
            </script>

            
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jom\espressoOasis\resources\views/shop/index.blade.php ENDPATH**/ ?>