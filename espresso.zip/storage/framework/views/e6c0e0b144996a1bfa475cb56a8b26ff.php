<nav class="navbar navbar-expand-sm bg-light justify-content-end">
    <ul class="navbar-nav">
        <div class="dropdown">
            <button class="btn btn-light dropdown-toggle" type="button" id="dropdownMenuButton"
                data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fa-solid fa-user"></i>
                <?php if(Auth::check()): ?>
                    <?php echo e(Auth::user()->username); ?>

                <?php else: ?>
                    User
                <?php endif; ?>
            </button>
            <ul class="dropdown-menu bg-light" aria-labelledby="dropdownMenuButton">
                <?php if(Auth::check()): ?>
                    <li><a class="dropdown-item" href="<?php echo e(route('user.logout')); ?>">Logout</a></li>
                <?php else: ?>

                <?php endif; ?>
            </ul>
        </div>
    </ul>
  </nav><?php /**PATH C:\Users\Jom\espressoOasis\resources\views/partials/admintopNav.blade.php ENDPATH**/ ?>