
<?php $__env->startSection('title'); ?>
    Orders
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.admintopNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="content">
        <div class="container round bg-white p-2 p-0">
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
            <div class="card`body p-4">
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="card shadow border mb-4">
                        <div class="card-body">
                            <div class="row d-flex align-items-center border-bottom">
                                <div class="col">
                                    <div class="row p-3">
                                        <p><strong>Order ID: <?php echo e($order['id']); ?> </strong></p>
                                        <p class="medium mb-0"><strong>Date: <?php echo e(\Carbon\Carbon::parse($order['created_at'])->format('Y-m-d H:i')); ?></strong> </p>
                                        <p class="small mb-0">Name: <?php echo e($order['name']); ?> </p>
                                        <p class="small mb-0">Email: <?php echo e($order['email']); ?></p>
                                        <p class="small mb-0">Phone: <?php echo e($order['phone']); ?></p>
                                        <p class="small mb-0">Address: <?php echo e($order['address']); ?></p>
                                    </div>
                                </div>
                                <div class="col-md-auto">
                                </div>
                                <div class="col col-lg-2 text-align-right">
                                    <div class="col col-lg-2 text-align-right">
                                        <?php if($order['orderStatus'] == 'Order Complete'): ?>
                                            <button type="button" class="btn btn-success dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-expanded="false"><?php echo e($order['orderStatus']); ?> </button>
                                        <?php elseif($order['orderStatus'] == 'Processing' || $order['orderStatus'] == 'Serving'): ?>
                                            <button type="button" class="btn btn-warning dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-expanded="false"><?php echo e($order['orderStatus']); ?></button>
                                        <?php else: ?>
                                            <button type="button" class="btn btn-danger dropdown-toggle dropdown-toggle-split" data-bs-toggle="dropdown" aria-expanded="false"><?php echo e($order['orderStatus']); ?></button>
                                        <?php endif; ?>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item" href="<?php echo e(route('order.update', ['id' => $order->id, 'status' => 'Order Complete'])); ?>">Order Complete</a></li>
                                            <li><a class="dropdown-item" href="<?php echo e(route('order.update', ['id' => $order->id, 'status' => 'Processing'])); ?>">Processing</a></li>
                                            <li><a class="dropdown-item" href="<?php echo e(route('order.update', ['id' => $order->id, 'status' => 'Serving'])); ?>">Serving</a></li>
                                            <li><a class="dropdown-item" href="<?php echo e(route('order.update', ['id' => $order->id, 'status' => 'Cancelled'])); ?>">Cancelled</a></li>
                                          </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="d-flex justify-content-between align-items-center mb-">
                                <p class="lead fw-normal mb-0">Receipt</p>
                            </div>
                            <?php $__currentLoopData = $order->cart->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="row">
                                    <div class="col-md-2 text-center d-flex justify-content-center align-items-center">
                                        <img src="<?php echo e(asset($item['item']['imagePath'])); ?>" class="img-fluid"
                                            style="height: 100px; width: 120px" alt="Phone">
                                    </div>
                                    <div
                                        class="col-md-2 text-center d-flex justify-content-center align-items-center">
                                        <p class="text-muted mb-0"><?php echo e($item['item']['title']); ?></p>
                                    </div>
                                    <div
                                        class="col-md-2 text-center d-flex justify-content-center align-items-center">
                                        <p class="text-muted mb-0 small">
                                            <?php echo e(json_decode($item['item'], true)['sizes'][$item['size']]['label']); ?>

                                        </p>

                                    </div>
                                    <div
                                        class="col-md-3 text-center d-flex justify-content-center align-items-center">
                                        <p class="text-muted mb-0 small"><?php echo e($item['brew']); ?></p>
                                    </div>
                                    <div
                                        class="col-md-1 text-center d-flex justify-content-center align-items-center">
                                        <p class="text-muted mb-0 small">
                                            &#8369;<?php echo e(json_decode($item['item'], true)['sizes'][$item['size']]['price']); ?>

                                        </p>
                                    </div>
                                    <div
                                        class="col-md-1 text-center d-flex justify-content-center align-items-center">
                                        <p class="text-muted mb-0 small">Qty: <?php echo e($item['qty']); ?></p>
                                    </div>
                                    <div
                                        class="col-md-1 text-center d-flex justify-content-center align-items-center">
                                        <p class="text-muted mb-0 small">&#8369;<?php echo e($item['price']); ?></p>
                                    </div>
                                </div>
                                <hr class="mb-4" opacity: 1;>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            <div class="row d-flex align-items-center border-top">
                                <div class="col">
                                    <p class="text-muted mt-1 mb-0 small ms-xl-5">Checkout ID:
                                        <?php echo e($order['checkout_id']); ?> </p>
                                </div>
                                <div class="col-md-auto">
                                </div>
                                <div class="col col-lg-3 text-align-right">
                                    <p><strong>Total Price &#8369; <?php echo e($order->cart->totalPrice); ?></strong></p>
                                </div>
                            </div>
                            <div class="row d-flex align-items-center border-top">
                                <div class="col col-fluid">
                                    <div class="row p-3">
                                        <p><strong>Notes: </strong></p>
                                        <p class="small mb-0"><?php echo e($order['moreInfo']); ?> </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jom\espressoOasis\resources\views/admin/orders.blade.php ENDPATH**/ ?>