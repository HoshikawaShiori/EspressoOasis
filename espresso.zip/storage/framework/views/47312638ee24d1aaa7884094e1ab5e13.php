
<?php $__env->startSection('title'); ?>
    Cart
<?php $__env->stopSection(); ?>
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::to('src/css/shop-card.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php if(Session::has('cart')): ?>
        <div class="row">
            <div class="col-sm-8 offset-sm-2">
                <table class="table table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>Product Name</th>
                            <th>Unit Price</th>
                            <th>Quantity</th>
                            <th>Total Price</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $coffees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coffee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong><?php echo e(json_decode($coffee['item'], true)['sizes'][$coffee['size']]['label']); ?>-</strong><?php echo e($coffee['brew']); ?> <?php echo e($coffee['item']['title']); ?></td>
                                <td><?php echo e(json_decode($coffee['item'], true)['sizes'][$coffee['size']]['price']); ?></td>
                                <td>
                                    <div class="input-group ">
                                        <a href="<?php echo e(route('coffee.reduce', ['combinedKey' => "{$coffee['oID']}"])); ?>" class="btn btn-secondary btn-sm" type="button">-</a>
                                        <input type="text" class="form-control  text-center"
                                            value="<?php echo e($coffee['qty']); ?>" readonly>
                                            <a href="<?php echo e(route('coffee.increase', ['combinedKey' => "{$coffee['oID']}"])); ?>" class="btn btn-secondary btn-sm" type="button">+</a>

                                    </div>
                                </td>
                                <td>PHP <?php echo e($coffee['price']); ?></td>
                                <td>
                                    <a href= "<?php echo e(route('coffee.remove', ['combinedKey' => "{$coffee['oID']}"])); ?>" class="btn btn-danger btn-sm">Remove</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="text-center">
                    <strong>Total: PHP <?php echo e($totalPrice); ?></strong>
                    <form action="<?php echo e(route('coffee.checkoutForm')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <!-- Other form fields -->
                        <button type="submit" class="btn btn-primary">Checkout</button>
                    </form>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="row">
            <div class="col-sm-6 offset-sm-3 text-center">
                <h2>Cart is Empty</h2>
            </div>
        </div>
    <?php endif; ?>

</div>
<?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
            <script>
                $(document).ready(function () {
                    // Remove 'fixed-top' class onload
                    $('#navbar').removeClass('fixed-top');

                    $(window).scroll(function () {
                        // Add 'fixed-top' class on scroll
                        if ($(this).scrollTop() > 50) {
                            $('#navbar').addClass('fixed-top');
                        } else {
                            $('#navbar').removeClass('fixed-top');
                        }
                    });
                });
            </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jom\espressoOasis\resources\views/shop/cart.blade.php ENDPATH**/ ?>