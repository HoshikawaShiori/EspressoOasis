
<?php $__env->startSection('title'); ?>
    Accounts
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.admintopNav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <main class="content">
        <div class="container round bg-white p-2 p-0">
            <div class="row pb-2">
                <div class="col-xl-6 col-xxl-5 d-flex">
                    <div class="w-100">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col mt-0">
                                                <h5 class="card-title text-center">Total number of accounts</h5>
                                            </div>
                                            <div class="col-auto">
                                                <div class="stat text-primary">
                                                    <i class="align-middle" data-feather="users"></i>
                                                </div>
                                            </div>
                                        </div>
                                        <h1 class="mt-1 mb-3 text-center"><?php echo e(count($users)); ?></h1>
                                    </div>
                                </div>
                            </div>
                            <div class="col-sm-6 d-flex align-items-end">
                                <button type="button" class="btn btn-primary btn-lg" data-bs-toggle="modal"
                                    data-bs-target="#exampleModal">Create Account</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <table class="table align-middle mb-0 bg-white">
                    <thead class="bg-light">
                        <tr>
                            <th scope="col">id</th>
                            <th scope="col">Email</th>
                            <th scope="col">Username</th>
                            <th scope="col">Role</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($user->id); ?></th>

                                <td><?php echo e($user->email); ?></td>
                                <td><?php echo e($user->username); ?></td>
                                <td>
                                    <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($role->name); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  </td>
                                <td>
                                    <ul class="list-inline m-0">
                                        <li class="list-inline-item">
                                            <button class="btn btn-success btn-sm rounded-0" type="button"
                                                data-toggle="tooltip" data-placement="top" title="Edit"
                                                data-bs-toggle="modal" data-bs-target="#modal<?php echo e($user->id); ?>"
                                                id="#editmodal<?php echo e($user->id); ?>">
                                                <i class="fa fa-edit"></i>
                                            </button>
                                        </li>
                                        <li class="list-inline-item">
                                            <a id="del-<?php echo e($user->id); ?>"
                                                href="<?php echo e(route('user.destroy', ['id' => $user->id])); ?>"
                                                class="btn btn-danger btn-sm rounded-0" type="button" data-toggle="tooltip"
                                                data-placement="top" title="Delete"><i class="fa fa-trash"></i></a>
                                        </li>
                                    </ul>
                                </td>
                            </tr>
                            <div class="modal fade" id="modal<?php echo e($user->id); ?>" tabindex="-1" aria-labelledby="modal" aria-hidden="true">
                                <div class="modal-dialog  d-flex container-fluid">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h1 class="modal-title fs-5" id="modal">Edit Account</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="container col">
                                                <form method="POST" action="<?php echo e(route('account.edit', ['id' => $user->id])); ?>" id="editForm<?php echo e($user->id); ?>" name="editForm">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="mb-2">
                                                        <label for="editemail<?php echo e($user->id); ?>">Email:</label>
                                                        <input type="text" class="form-control" placeholder="editemail" id="editemail<?php echo e($user->id); ?>"
                                                            name="editemail" value="<?php echo e($user->email); ?>" required>
                                                        <label for="editusername<?php echo e($user->id); ?>">Username:</label>
                                                        <input type="editusername" class="form-control" placeholder="username" minlength="6" id="editusername<?php echo e($user->id); ?>"
                                                            name="editusername" value="<?php echo e($user->username); ?>" required>
                                                        <p class="text-sm text-danger">Leave password field blank if there is no update intent</p>
                                                        <label for="editpassword<?php echo e($user->id); ?>">Password:</label>
                                                        <input type="password" class="form-control" placeholder="Password" minlength="8" id="editpassword<?php echo e($user->id); ?>"
                                                            name="editpassword">
                                                        <label for="editconfirm_password<?php echo e($user->id); ?>">Confirm Password:</label>
                                                        <input type="password" class="form-control" minlength="8" placeholder="Confirm Password"
                                                            id="editconfirm_password<?php echo e($user->id); ?>"  name="editconfirm_password">
                                                        <label for="editrole<?php echo e($user->id); ?>">Select a role:</label>
                                                        <select class="form-select form-control mt-3" aria-label="Select a role" id="editrole<?php echo e($user->id); ?>" name="editrole" required>
                                                                <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="1" <?php echo e($role->id == 1 ? 'selected' : ''); ?>>admin</option>
                                                                <option value="2" <?php echo e($role->id== 2 ? 'selected' : ''); ?>>user</option>
                                                                <option value="3" <?php echo e($role->id == 3 ? 'selected' : ''); ?>>superadmin</option>
                                                                <option value="4" <?php echo e($role->id == 4 ? 'selected' : ''); ?>>attendant</option>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
                                                        </select>
                    
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-bs-dismiss="modal">Close</button>
                                                        <input type="submit" id="submitedit<?php echo e($user->id); ?>" form="editForm<?php echo e($user->id); ?>" class="btn btn-primary">
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                                <script>
                                    $(document).ready(function() {  
                                    var selectedRole = $(this).find(":selected").text(); 
                                    $('#editForm<?php echo e($user->id); ?>').attr('action', `<?php echo e(route('account.create', ['role' => ':roleName'])); ?>`.replace(':roleName', selectedRole));
                            
                            
                                        $('#role').on('change', function() {
                                            var selectedRole = $(this).find(":selected").text();
                                            var createAccountUrl = "<?php echo e(route('account.create', ['role' => 'selectedRole'])); ?>";
                                            createAccountUrl = createAccountUrl.replace('selectedRole', selectedRole);
                                            $('#createForm').attr('action', createAccountUrl);
                                        });
                                    });
                                </script>

                                <script>
                                    var password = document.getElementById("editpassword<?php echo e($user->id); ?>"),
                                        confirm_password = document.getElementById("editconfirm_password<?php echo e($user->id); ?>");

                                    function validatePassword() {
                                        if (password.value != confirm_password.value) {
                                            confirm_password.setCustomValidity("Passwords Don't Match");
                                            console.log(password.value + "||" + confirm_password.value);
                                        } else {
                                            confirm_password.setCustomValidity('');
                                        }
                                    }

                                    password.onchange = validatePassword;
                                    confirm_password.onkeyup = validatePassword;
                                </script>
                                
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="modal" aria-hidden="true">
            <div class="modal-dialog  d-flex container-fluid">
                <div class="modal-content">
                    <div class="modal-header">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Accout</h1>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="container col">
                            <form method="POST" action="" id="createForm" name="createForm">
                                <?php echo csrf_field(); ?>
                                <div class="mb-2">
                                    <label for="email">Email:</label>
                                    <input type="text" class="form-control" placeholder="email" id="email"
                                        name="email" required>
                                    <label for="username">Username:</label>
                                    <input type="username" class="form-control" placeholder="username" id="username"
                                        name="username" required>
                                    <label for="password">Password:</label>
                                    <input type="password" class="form-control" placeholder="Password" id="password"
                                        name="password" required>
                                    <label for="confirm_password">Confirm Password:</label>
                                    <input type="password" class="form-control" placeholder="Confirm Password"
                                        id="confirm_password" name="confirm_password" required>
                                    <label for="role">Select a role:</label>
                                    <select class="form-select form-control mt-3" aria-label="Select a role" id="role" name="role" required>
                                            <option value="1" selected>attendant</option>
                                            <option value="2">admin</option>
                                            <option value="3">superadmin</option>
                                    </select>

                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Close</button>
                                    <input type="submit" form="createForm" class="btn btn-primary">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        var password = document.getElementById("password"),
            confirm_password = document.getElementById("confirm_password");

        function validatePassword() {
            if (password.value != confirm_password.value) {
                confirm_password.setCustomValidity("Passwords Don't Match");
                console.log(password.value + "||" + confirm_password.value);
            } else {
                confirm_password.setCustomValidity('');
            }
        }

        password.onchange = validatePassword;
        confirm_password.onkeyup = validatePassword;
    </script>

    <script>
        $(document).ready(function() {  
        var selectedRole = $(this).find(":selected").text(); 
        $('#createForm').attr('action', `<?php echo e(route('account.create', ['role' => ':roleName'])); ?>`.replace(':roleName', selectedRole));


            $('#role').on('change', function() {
                var selectedRole = $(this).find(":selected").text();
                var createAccountUrl = "<?php echo e(route('account.create', ['role' => 'selectedRole'])); ?>";
                createAccountUrl = createAccountUrl.replace('selectedRole', selectedRole);
                $('#createForm').attr('action', createAccountUrl);
            });
        });
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layoutAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jom\espressoOasis\resources\views/admin/accounts.blade.php ENDPATH**/ ?>